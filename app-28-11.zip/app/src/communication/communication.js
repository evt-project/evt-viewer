/**
 * @ngdoc overview
 * @name evtviewer.communication
 * @description 
 * # evtviewer.communication
 * Module referring to communication operations.
**/
angular.module('evtviewer.communication', []);