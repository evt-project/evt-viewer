/**
 * @ngdoc overview
 * @name evtviewer.Mobile
 * @module evtviewer.Mobile
 * @description ...
**/
angular.module('evtviewer.mobile', ['ngRoute','ngAnimate','ngTouch']);